#include <iostream>
int main(){
    using namespace std;
    cout<<"hello"<<endl;
    return 0;
}