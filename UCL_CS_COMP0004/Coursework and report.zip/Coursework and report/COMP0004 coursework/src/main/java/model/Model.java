package model;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Collections;
public class Model
{
  @SuppressWarnings("unchecked")
  private Hashtable<String,Hashtable<String,String>> deserialization(File file) throws IOException,ClassNotFoundException
  {
    ObjectInputStream deserialization =  new ObjectInputStream(new FileInputStream(file));
    Hashtable <String,Hashtable<String,String>> resultObject = (Hashtable <String,Hashtable<String,String>>) deserialization.readObject();
    deserialization.close();
    return resultObject;
  }

  @SuppressWarnings("unchecked")
  private Hashtable<String,ArrayList<Hashtable<String,String>>> deserialization(File file,String type) throws IOException,ClassNotFoundException
  {
    ObjectInputStream deserialization =  new ObjectInputStream(new FileInputStream(file));
    Hashtable<String,ArrayList<Hashtable<String,String>>> resultObject = (Hashtable<String,ArrayList<Hashtable<String,String>>>) deserialization.readObject();
    deserialization.close();
    return resultObject;
  }

  private void serialization(File file, Hashtable <String,Hashtable<String,String>> targetObject) throws IOException
  {
    ObjectOutputStream serialization = new ObjectOutputStream(new FileOutputStream(file));
    serialization.writeObject(targetObject);
    serialization.close();
  }

  private void serialization(File file, Hashtable <String, ArrayList<Hashtable<String,String>>> targetObject, String type) throws IOException
  {
    ObjectOutputStream serialization = new ObjectOutputStream(new FileOutputStream(file));
    serialization.writeObject(targetObject);
    serialization.close();
  }

  public ArrayList<Hashtable<String,String>> searchFor(String searchString) throws ClassNotFoundException, IOException
  {
    searchString = searchString.replace(" ",""); 
    Hashtable<String,Hashtable<String,String>> allNote = readFile("data/nameNotehashTable");
    ArrayList<Hashtable<String,String>> searchResult = new ArrayList<Hashtable<String,String>>();
    Enumeration<String> keyList = allNote.keys();
    while(keyList.hasMoreElements())
    {
        String currKey = (String)keyList.nextElement();
        Hashtable<String,String> currNote = allNote.get(currKey);
        if(currKey.indexOf(searchString)!=-1)
        {
            searchResult.add(currNote);
        }
        else if(currNote.get("index").indexOf(searchString)!=-1)
        {
            searchResult.add(currNote);
        }
        else if(currNote.get("content").indexOf(searchString)!=-1)
        {
            searchResult.add(currNote);
        }
    }
    return searchResult;
  }

  private Hashtable<String,String> buildNote(String title, String index, String content, String time)
  {
    Hashtable<String,String> newNote = new Hashtable<String,String>();
    newNote.put("title",title);
    newNote.put("index",index);
    newNote.put("content",content);
    newNote.put("time",time);
    return newNote;
  }

  public void saveNote(String title, String index, String content, String time) throws IOException,ClassNotFoundException
  {
    File nameFile = new File("data/nameNotehashTable/");
    File indexFile = new File("data/IndexNotehashTable/");
    Hashtable<String,String> newNote = buildNote(title, index, content, time);
    if (!indexFile.exists())
    {
      indexFile.createNewFile();
      Hashtable <String, ArrayList<Hashtable<String,String>>> indexObject = new Hashtable <String, ArrayList<Hashtable<String,String>>>();
      serialization(indexFile, indexObject,"index");               
    }
    if (!nameFile.exists())
    {
      nameFile.createNewFile();
      Hashtable <String,Hashtable<String,String>> nameObject = new Hashtable<String,Hashtable<String,String>>();
      serialization(nameFile, nameObject); 
    }
    Hashtable <String,Hashtable<String,String>> indexObject = deserialization(nameFile);
    Hashtable <String, ArrayList<Hashtable<String,String>>> nameObject = deserialization(indexFile,"index");
    indexObject.put(title,newNote);
    if(nameObject.get(index) == null)
    {
      nameObject.put(index,new ArrayList<Hashtable<String,String>>());
    }
    ArrayList<Hashtable<String,String>> noteList = nameObject.get(index);
    noteList.add(newNote);
    serialization(nameFile, indexObject);
    serialization(indexFile, nameObject,"index");
  }

  public Hashtable<String,Hashtable<String,String>> readFile(String address) throws ClassNotFoundException, IOException
  {
    String noteAddress = address;
    File file = new File(noteAddress);
    if (!file.exists())
    {
      file.createNewFile();
      Hashtable <String,Hashtable<String,String>> nameObject = new Hashtable<String,Hashtable<String,String>>();
      serialization(file, nameObject); 
    }
    Hashtable <String,Hashtable<String,String>> resultHashtable = deserialization(file);
    return resultHashtable;
  }

  public Hashtable<String,ArrayList<Hashtable<String,String>>> readFile(String address,String type) throws ClassNotFoundException, IOException
  {
    String noteAddress = address;
    File file = new File(noteAddress);
    if (!file.exists())
    {
      file.createNewFile();
      Hashtable <String, ArrayList<Hashtable<String,String>>> indexObject = new Hashtable <String, ArrayList<Hashtable<String,String>>>();
      serialization(file, indexObject,"index");               
    }
    Hashtable<String,ArrayList<Hashtable<String,String>>> resultHashtable = deserialization(file,"index");
    return resultHashtable;
  }

  public Hashtable<String,String> getNoteByTitle(String title) throws IOException,ClassNotFoundException
  {
    Hashtable<String,Hashtable<String,String>> noteList = readFile("data/nameNotehashTable");
    Hashtable<String,String> requiredNote = noteList.get(title);
    return requiredNote;
  }

  public void deleteNote(String delTitle,String delIndex) throws IOException,ClassNotFoundException
  {
    Hashtable<String,Hashtable<String,String>> nameObject = readFile("data/nameNotehashTable");
    File indexFile = new File("data/IndexNotehashTable/");
    Hashtable <String, ArrayList<Hashtable<String,String>>> indexObject = deserialization(indexFile,"index");
    nameObject.remove(delTitle);
    ArrayList<Hashtable<String,String>> indexTable = indexObject.get(delIndex);
    for(Hashtable<String,String> name : indexTable)
    {
      if(delTitle.equals(name.get("title")))
      {
        indexTable.remove(name);
        indexObject.put(delIndex,indexTable);
        break;
      }
    }
    File nameFile = new File("data/nameNotehashTable/");
    serialization(nameFile, nameObject);
    serialization(indexFile, indexObject,"index");
  }
  public ArrayList<String> getIndexList() throws ClassNotFoundException ,IOException
  {
    Hashtable<String,ArrayList<Hashtable<String,String>>> indexNotes = readFile("data/IndexNotehashTable","index");
    ArrayList<String> indexList = new ArrayList<String>();
    Enumeration<String> index = indexNotes.keys();
      while(index.hasMoreElements())
      {
        String currIndex = (String) index.nextElement();
        indexList.add(currIndex);
        Collections.sort(indexList);
      }
      return indexList;
  }
  public ArrayList <Hashtable<String,String>> getCurrentNoteList() throws ClassNotFoundException, IOException
  {
    Hashtable<String,Hashtable<String,String>> allNote = readFile("data/nameNotehashTable");
    Enumeration<String> key = allNote.keys();
    ArrayList <Hashtable<String,String>> timeList= new ArrayList <Hashtable<String,String>>();
    while(key.hasMoreElements())
    {
        Hashtable<String,String> currNote = allNote.get(key.nextElement());
        timeList.add(currNote);
    }
    for(int i =0;i<timeList.size()-1;i++)
    {
        for(int j =0;j<timeList.size()-i-1;j++)
        {
            if(timeList.get(j).get("time").compareTo(timeList.get(j+1).get("time")) < 0 ){
                Hashtable<String,String> temp = timeList.get(j);
                timeList.set(j, timeList.get(j+1));
                timeList.set(j+1, temp);
            }
        }
    }
    return timeList;
  }
}
