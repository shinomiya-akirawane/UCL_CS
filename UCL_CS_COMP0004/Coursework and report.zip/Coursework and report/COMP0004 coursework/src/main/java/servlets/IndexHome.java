package servlets;

import model.Model;
import model.ModelFactory;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Hashtable;

@WebServlet("/")
public class IndexHome extends HttpServlet
{
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    try
    {
      Model model = ModelFactory.getModelOfNote();
      Hashtable<String,ArrayList<Hashtable<String,String>>> indexNotes = model.readFile("data/IndexNotehashTable","index");
      if(indexNotes == null)
      {
        ServletContext context = getServletContext();
        RequestDispatcher dispatch = context.getRequestDispatcher("/newNote.html");
        dispatch.forward(request, response);
      }
      ArrayList<String> indexList = model.getIndexList();
      request.setAttribute("indexList", indexList);
    }
    catch(ClassNotFoundException c)
    {
      response.sendRedirect("/errorPage.html");
    }
    ServletContext context = getServletContext();
    RequestDispatcher dispatch = context.getRequestDispatcher("/initHome.jsp");
    dispatch.forward(request, response);
  }
}
