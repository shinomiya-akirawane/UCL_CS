package servlets;

import model.Model;
import model.ModelFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;

import java.io.IOException;

import java.util.Hashtable;


@WebServlet("/editNote")
@MultipartConfig
public class EditNoteSerlvet extends HttpServlet
{
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    try
    {
      String title = request.getParameter("openNote");
      Model model = ModelFactory.getModelOfNote();
      Hashtable<String, String> note = model.getNoteByTitle(title);
      String index = note.get("index");
      String content = note.get("content");
      request.setAttribute("title", title);
      request.setAttribute("index", index);
      request.setAttribute("content", content);
      ServletContext context = getServletContext();
      RequestDispatcher dispatch = context.getRequestDispatcher("/editNote.jsp");
      dispatch.forward(request, response);
    }
    catch(ClassNotFoundException c)
    {
      response.sendRedirect("/errorPage.html");
    }
  }
}