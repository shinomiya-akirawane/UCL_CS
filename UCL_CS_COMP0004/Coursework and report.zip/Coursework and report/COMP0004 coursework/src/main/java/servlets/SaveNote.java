package servlets;

import model.Model;
import model.ModelFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;

import java.io.IOException;

import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

@WebServlet("/SaveNote")
@MultipartConfig
public class SaveNote extends HttpServlet
{
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    String title = request.getParameter("title");
    String index = request.getParameter("index");
    String content = request.getParameter("content");
    String pastTitle = request.getParameter("pastTitle");
    LocalDateTime now = LocalDateTime.now();
    DateTimeFormatter ofPattern = DateTimeFormatter.ofPattern("yyyyMMddhhmmssSSS");
    String formatDate = ofPattern.format(now);
    Model model = ModelFactory.getModelOfNote();
    try
    {
      if(pastTitle != title && pastTitle != null)
      {
        model.deleteNote(pastTitle, index);
        model.saveNote(title, index, content,formatDate);
      }
      else
      {
        model.saveNote(title, index, content,formatDate);
      }
    }
    catch(ClassNotFoundException c)
    {
      response.sendRedirect("/errorPage.html");
    }
    ServletContext context = getServletContext();
    RequestDispatcher dispatch = context.getRequestDispatcher("/initHome.html");
    dispatch.forward(request, response);
  }
}