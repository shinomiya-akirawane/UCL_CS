Example Java web application for COMP0004
